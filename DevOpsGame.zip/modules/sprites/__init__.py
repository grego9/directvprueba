'''初始化'''
from .dinosaur import Dinosaur
from .obstacle import Cactus, Ptera
from .scene import Ground, Cloud, Scoreboard